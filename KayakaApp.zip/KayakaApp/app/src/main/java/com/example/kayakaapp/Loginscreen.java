package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kayakaapp.Models.Userdetailsmodel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Loginscreen extends AppCompatActivity {

    MaterialButton  login;
    TextView forgotpassword, register;
    TextInputLayout phonenumber, password;
    ProgressBar progressBar;
    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginscreen);

        login = findViewById(R.id.login);
        forgotpassword = findViewById(R.id.forgot_password);
        register = findViewById(R.id.register);
        phonenumber = findViewById(R.id.phone_number);
        password = findViewById(R.id.password);
        progressBar = findViewById(R.id.progressbar);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (!validate_text(phonenumber) | !validate_text(password)) {
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);
                login.setVisibility(View.INVISIBLE);


                database.getReference().child("Users").child(phonenumber.getEditText().getText().toString())
                        .child("Userdetails").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Userdetailsmodel userdetailsmodel = snapshot.getValue(Userdetailsmodel.class);
                        try {
                            if (phonenumber.getEditText().getText().toString().equals(userdetailsmodel.getPhonenumber())
                                    && (password.getEditText().getText().toString().equals(userdetailsmodel.getPassword()))) {
                                Intent intent = new Intent(Loginscreen.this, Verifyotpscreentwo.class);
                                intent.putExtra("Name", userdetailsmodel.getName());
                                intent.putExtra("Phonenumber", userdetailsmodel.getPhonenumber());
                                intent.putExtra("Password", userdetailsmodel.getPassword());
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(Loginscreen.this, "Phone Number and password does not match",
                                        Toast.LENGTH_SHORT).show();
                            }
                            progressBar.setVisibility(View.INVISIBLE);
                            login.setVisibility(View.VISIBLE);
                        } catch (NullPointerException e) {
                            Toast.makeText(Loginscreen.this, "Phone Number Not Registered", Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.INVISIBLE);
                            login.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(Loginscreen.this, error.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });

        forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Loginscreen.this, Forgotpasswordscreen.class));
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Loginscreen.this, Signupscreen.class));
            }
        });

        //IF user already signed then go to main activity
        if(auth.getCurrentUser()!=null){

            Intent intent = new Intent(Loginscreen.this, MainActivity.class);
            startActivity(intent);
            finish();

        }
    }
    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }
}