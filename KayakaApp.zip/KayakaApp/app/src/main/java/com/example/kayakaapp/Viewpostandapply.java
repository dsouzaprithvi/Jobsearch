package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kayakaapp.Models.Applymodel;
import com.example.kayakaapp.Models.Postsmodel;
import com.example.kayakaapp.Models.Userdetailsmodel;
import com.example.kayakaapp.databinding.ActivityViewpostandapplyBinding;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

public class Viewpostandapply extends AppCompatActivity {

//    TextView amount, title, description,
//            paymentmode, category, location,
//            pincode, visitprofile;

//    TextInputLayout offeredamount, message;
//
//    MaterialButton apply;

    FirebaseAuth auth;
    FirebaseDatabase database;

    Userdetailsmodel currentuser;

    private ActivityViewpostandapplyBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewpostandapplyBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);


//        title = findViewById(R.id.tittle);
//        description = findViewById(R.id.description);
//        paymentmode = findViewById(R.id.paymentmode);
//        category = findViewById(R.id.category);
//        location = findViewById(R.id.location);
//        pincode = findViewById(R.id.pincode);
//        visitprofile = findViewById(R.id.visitprofile);
//        offeredamount = findViewById(R.id.offeredamount);
//        message = findViewById(R.id.message);
//        apply = findViewById(R.id.apply);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        Gson gson = new Gson();
        Postsmodel data = gson.fromJson(getIntent().getStringExtra("Postdata"), Postsmodel.class);
//        Log.i("Postadtat_->>", data.getPincode());
        try {
            String post = getIntent().getStringExtra("Appliedfragment");

            if ( post.equals("yes") ) {
                binding.apply.setVisibility(View.GONE);
            }
        } catch ( NullPointerException e ) {
            e.printStackTrace();
        }

        binding.amount.setText(data.getStartpay());
        binding.tittle.setText(data.getTitle());
        binding.description.setText(data.getDescription());
        binding.location.setText(data.getLocation());
        if ( data.getCash().equals("No")) {
            binding.paymentmode.setText("Cashless Payment");
        } else {
            binding.paymentmode.setText("Cash Payment");
        }
        binding.amount.setText(data.getStartpay());
        binding.pincode.setText(data.getPincode());

        database.getReference().child("Users")
                .child(auth.getCurrentUser().getPhoneNumber())
                .child("Userdetails")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        currentuser = snapshot.getValue(Userdetailsmodel.class);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        database.getReference().child("Users/"+data.getPhonenumber()+"/Userdetails")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Userdetailsmodel users = snapshot.getValue(Userdetailsmodel.class);
                Picasso.get().load(users.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(binding.profilePic);
                binding.userName.setText(users.getName());
                try {
                    binding.rating.setText(users.getRating());
                } catch ( NullPointerException e ) {

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        binding.visitprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Viewpostandapply.this, Viewprofile.class);
                intent.putExtra("Phonenumber", data.getPhonenumber());
                startActivity(intent);
            }
        });

        binding.apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                if ( !validate_text(binding.message) | !validate_text(binding.offeredamount) ) {
//                    return;
//                }

                String pin = data.getPincode();
                String date = data.getDatetime();
                String postid =  data.getPhonenumber();
                Applymodel applymodel = new Applymodel(currentuser.getName(),
                        currentuser.getPhonenumber(), currentuser.getProfilepic());
                database.getReference().child("Posts")
                        .child(pin)
                        .child(postid)
                        .child(date)
                        .child("ApplyRequest")
                        .child(currentuser.getPhonenumber())
                        .setValue(applymodel);
                Toast.makeText(Viewpostandapply.this, "Apply Successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Viewpostandapply.this, MainActivity.class));
                finish();
            }
        });

    }

    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    //    private void loaduserdata() {
//
//        database.getReference().child("Users/"+)
//    }
}