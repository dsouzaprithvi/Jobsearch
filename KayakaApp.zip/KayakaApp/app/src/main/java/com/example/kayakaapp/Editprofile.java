package com.example.kayakaapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.kayakaapp.Models.Userdetailsmodel;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.FileNotFoundException;

import de.hdodenhof.circleimageview.CircleImageView;

public class Editprofile extends AppCompatActivity {

    FloatingActionButton updateprfilepic;
    CircleImageView profilepic;
    TextInputLayout fullname, dob;
    MaterialButton update;
    Button back;
    RadioButton male, female, other, radioButton;
    RadioGroup gender;

    Uri selectedImageUri;
    Bitmap bitmap;

    FirebaseAuth auth;
    FirebaseDatabase database;
    FirebaseStorage storage;

    Dialog progressDialog;

    ActivityResultLauncher mTakePhoto;

    String phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editprofile);

        update = findViewById(R.id.update);
        updateprfilepic = findViewById(R.id.updateprofilepic);
        profilepic = findViewById(R.id.profile_pic);
        fullname = findViewById(R.id.full_name);
        back = findViewById(R.id.back_button);
        dob = findViewById(R.id.dob);
        male = findViewById(R.id.male);
        female = findViewById(R.id.female);
        other = findViewById(R.id.other);
        gender = findViewById(R.id.gender);

        auth = FirebaseAuth.getInstance();
        phone = auth.getCurrentUser().getPhoneNumber();
        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

        progressDialog = new Dialog(Editprofile.this);
        progressDialog.setContentView(R.layout.progress_dialog);
        progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        progressDialog.setCancelable(false);


        database.getReference().child("Users").child(phone)
                .child("Userdetails").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Userdetailsmodel users = snapshot.getValue(Userdetailsmodel.class);
                        Picasso.get().load(users.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
                        fullname.getEditText().setText(users.getName());
                        dob.getEditText().setText(users.getDob());
                        String gender = users.getGender();
                        try {
                            if ( gender.equals("Male") ) {
                                male.setChecked(true);
                            } else if ( gender.equals("Female")) {
                                female.setChecked(true);
                            } else {
                                other.setChecked(true);
                            }
                        } catch (NullPointerException e) {

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


        mTakePhoto = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            if (result.getData() != null) {
                                selectedImageUri = result.getData().getData();
                                try {
                                    bitmap = BitmapFactory.decodeStream(getBaseContext().
                                            getContentResolver().openInputStream(selectedImageUri));
                                    profilepic.setImageBitmap(bitmap);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                }
                                // set bitmap to image view here........
                            }
                        }
                    }
                });

        updateprfilepic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                mTakePhoto.launch(intent);
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!(male.isChecked() || female.isChecked() ||
                        (other.isChecked())) ) {
                    Toast.makeText(Editprofile.this, "Field not selected", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!validate_text(fullname) | !validate_text(dob)) {
                    return;
                }

                String dateofbirth = radiobuttonlistener(gender);
                Userdetailsmodel user = new Userdetailsmodel(fullname.getEditText().getText().toString(),
                        dob.getEditText().getText().toString(), dateofbirth);
                progressDialog.show();
                try {
                    storage.getReference().child("Profile_pictures")
                            .child(phone)
                            .putFile(selectedImageUri)
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    storage.getReference().child("Profile_pictures")
                                            .child(phone)
                                            .getDownloadUrl()
                                            .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                @Override
                                                public void onSuccess(Uri uri) {
                                                    database.getReference().child("Users")
                                                            .child(phone)
                                                            .child("Userdetails").child("profilepic").setValue(uri.toString());
                                                    Toast.makeText(Editprofile.this,
                                                            "Image Uploaded Successfully", Toast.LENGTH_SHORT).show();

                                                }
                                            });
                                }
                            });
                } catch (Exception e) {

                }

                database.getReference().child("Users/"+phone+"/Userdetails/name").setValue(user.getName());
                database.getReference().child("Users/"+phone+"/Userdetails/dob").setValue(user.getDob());
                database.getReference().child("Users/"+phone+"/Userdetails/gender").setValue(user.getGender());
                Toast.makeText(Editprofile.this, "Updated successfully", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }

    private String radiobuttonlistener(RadioGroup radioGroup) {
        int selectID = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(selectID);
        return radioButton.getText().toString();
    }
}