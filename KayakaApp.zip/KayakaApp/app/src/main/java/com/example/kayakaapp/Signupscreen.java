package com.example.kayakaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Signupscreen extends AppCompatActivity {

    TextInputLayout fullname, phonenumber, password, confirmpassword;
    MaterialButton register;
    TextView login;

    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signupscreen);

        register = findViewById(R.id.register);
        login = findViewById(R.id.login);
        fullname = findViewById(R.id.full_name);
        phonenumber = findViewById(R.id.phone_number);
        password = findViewById(R.id.password);
        confirmpassword = findViewById(R.id.confirm_password);


        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if ( !validate_text(fullname) | !validate_text(phonenumber) |
                        !validate_text(password) | !validate_text(confirmpassword)) {
                    return;
                }

                if (!validate_password()) {
                    return;
                }

                Intent intent = new Intent(Signupscreen.this, Verifyotpscreen.class);
                intent.putExtra("Name", fullname.getEditText().getText().toString());
                intent.putExtra("Phonenumber", phonenumber.getEditText().getText().toString());
                intent.putExtra("Password", password.getEditText().getText().toString());
                startActivity(intent);
//                startActivity(new Intent(Signupscreen.this, Verifyotpscreen.class));
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Signupscreen.this, Loginscreen.class));
            }
        });
    }

    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }


    private boolean validate_password(){
        String pass = password.getEditText().getText().toString();
        String cpass = confirmpassword.getEditText().getText().toString();
        if (pass.equals(cpass)){
            confirmpassword.setError(null);
            confirmpassword.setErrorEnabled(false);
            return true;
        } else {
            confirmpassword.setError("Password does not match");
            return false;
        }
    }
}