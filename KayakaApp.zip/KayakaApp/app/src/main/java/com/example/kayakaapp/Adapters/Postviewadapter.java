package com.example.kayakaapp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kayakaapp.Editpost;
import com.example.kayakaapp.Models.Postsmodel;
import com.example.kayakaapp.R;
import com.example.kayakaapp.Viewpostandapply;

import java.util.ArrayList;

public class Postviewadapter extends RecyclerView.Adapter<Postviewadapter.MyViewholder>{

    Context context;
    ArrayList<Postsmodel> postsmodels;

    private OnItemLongClickListener mlongListener;

    private OnItemClickListener mListener;

    public interface OnItemLongClickListener {

        void onLongClick(int position);
    }

    public void setOnLongClickListener(OnItemLongClickListener longClickListener) {
        mlongListener = longClickListener;
    }

    public interface OnItemClickListener {

//        void onEditClick(int position);

        void onCardviewclick(int position);
    }

    public void setOnItemClickListener(Postviewadapter.OnItemClickListener listener) {
        mListener = listener;
    }

    public Postviewadapter(Context context, ArrayList<Postsmodel> postsmodels) {
        this.context = context;
        this.postsmodels = postsmodels;
    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_postview, parent, false);
        return new Postviewadapter.MyViewholder(view, mListener, mlongListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {
        Postsmodel data = postsmodels.get(position);

        holder.jobstatus.setText(data.getStatus());
        holder.jobtype.setText(data.getJobtype());
        holder.jobtitle.setText(data.getTitle());
        holder.jobdescription.setText(data.getDescription());
        holder.jobcategory.setText(data.getCategory());
        holder.time.setText(data.getDatetime());
        holder.pay.setText(data.getStartpay());
        holder.payas.setText(data.getPayas());

        if ( data.getCategory().equals("Need Job") ) {
            holder.jobtype.setBackground(context.getDrawable(R.drawable.backgroundblue));
            holder.jobtype.setTextColor(context.getResources().getColor(R.color.white));

        } else {
            holder.jobtype.setBackground(context.getDrawable(R.drawable.backgroundyellow));
        }

    }

    @Override
    public int getItemCount() {
        return postsmodels.size();
    }

    public class MyViewholder extends RecyclerView.ViewHolder {

        TextView jobstatus, jobtype, jobtitle, jobdescription,
                jobcategory, time, pay, payas;

        CardView cardView;


        public MyViewholder(@NonNull View itemView, final Postviewadapter.OnItemClickListener listener, final OnItemLongClickListener longlistener) {
            super(itemView);

            jobstatus = itemView.findViewById(R.id.status);
            jobtype = itemView.findViewById(R.id.jobtype);
            time = itemView.findViewById(R.id.time);
            jobtitle = itemView.findViewById(R.id.jobtitle);
            jobdescription = itemView.findViewById(R.id.jobdescription);
            jobcategory = itemView.findViewById(R.id.jobcategory);
            pay = itemView.findViewById(R.id.pay);
            payas = itemView.findViewById(R.id.payas);
            cardView = itemView.findViewById(R.id.cardview);

            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onCardviewclick(position);
                        }
                    }
                }
            });

            cardView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    if (longlistener!=null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            longlistener.onLongClick(position);
                        }
                    }
                    return true;
                }
            });

        }
    }
}
