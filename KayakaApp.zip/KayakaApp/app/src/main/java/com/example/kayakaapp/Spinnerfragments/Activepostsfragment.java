package com.example.kayakaapp.Spinnerfragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.kayakaapp.Adapters.Postadapter;
import com.example.kayakaapp.Editpost;
import com.example.kayakaapp.Editprofile;
import com.example.kayakaapp.MainActivity;
import com.example.kayakaapp.Models.Postsmodel;
import com.example.kayakaapp.Models.Userdetailsmodel;
import com.example.kayakaapp.Models.Viewuser;
import com.example.kayakaapp.R;
import com.example.kayakaapp.Viewusers;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class Activepostsfragment extends Fragment {


    ArrayList<Postsmodel> postholder;
    Postadapter adapter;
    RecyclerView recyclerView;


    FirebaseAuth auth;
    FirebaseDatabase database;

    public Activepostsfragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_activepostsfragment, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        postholder = new ArrayList<>();
        adapter = new Postadapter(getContext(), postholder);
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new Postadapter.OnItemClickListener() {
            @Override
            public void onCardviewclick(int position) {
//                Intent intent = new Intent(getContext(), Editpost.class);
//                intent.putExtra("Posts", "yes");
//                intent.putExtra("Time", postholder.get(position).getDatetime());
//                intent.putExtra("Pincode", postholder.get(position).getPincode());
//                startActivity(intent);
                viewappliedlist(position);
            }

            @Override
            public void onEditClick(int position) {

            }

            @Override
            public void onDeleteClick(int position) {
                removeItem(position);
            }
        });

        loaddata();


        return view;
    }

    private void loaddata() {

        String phonenumber = auth.getCurrentUser().getPhoneNumber();

        database.getReference().child("Posts")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        postholder.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            for (DataSnapshot child : dataSnapshot.getChildren()) {
                                if ( child.getKey().equals(phonenumber) ) {
                                    for (DataSnapshot posts : child.getChildren()) {
                                        for (DataSnapshot postdetails : posts.getChildren()) {
                                            if (postdetails.getKey().equals("Postdetails")) {
                                                Postsmodel postsmodel = postdetails.getValue(Postsmodel.class);
                                                if (postsmodel.getStatus().equals("Activepost")) {
                                                    postholder.add(postsmodel);
                                                    String data = String.valueOf(database.getReference());
                                                    Log.i("Post--->", data);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

//    public void getpincode() {
//        MainActivity mainActivity = (MainActivity) getActivity();
//        Bundle bundle = mainActivity.getMyData();
//        pincode = bundle.getString("Pincode");
//        Log.i("Pincode----Main>",pincode);
//    }

    public void removeItem(int position){
        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setIcon(R.drawable.ic_baseline_warning_24)
                .setTitle("Delete")
                .setMessage("Are you sure to delete")
                .setPositiveButton("OK", null)
                .setNegativeButton("Cancel", null)
                .show();

        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        positiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String date = postholder.get(position).getDatetime();
                String pincode = postholder.get(position).getPincode();
                postholder.remove(position);
                adapter.notifyItemRemoved(position);
                String id = auth.getCurrentUser().getPhoneNumber();
                database.getReference().child("Posts").child(pincode).child(id).child(date).removeValue();
//                database.getReference().child("Users").child(id).child("Savedposts").child(date).removeValue();
                dialog.dismiss();
            }
        });
    }

    private void viewappliedlist(int position) {
        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setTitle("View Applied Users")
                .setPositiveButton("Post Completed", null)
                .setNegativeButton("View List", null)
                .show();

        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        positiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Postsmodel post = postholder.get(position);
                database.getReference().child("Posts").child(post.getPincode())
                        .child(auth.getCurrentUser().getPhoneNumber())
                        .child(post.getDatetime())
                        .child("Postdetails")
                        .child("status")
                        .setValue("Completed").addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(getContext(), "Post Completed Successfully", Toast.LENGTH_SHORT).show();
                            }
                        });
                dialog.dismiss();
            }
        });

        Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        negativeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Viewusers.class);
                intent.putExtra("Time", postholder.get(position).getDatetime());
                intent.putExtra("Pincode", postholder.get(position).getPincode());
                startActivity(intent);
                dialog.dismiss();
            }
        });
    }
}