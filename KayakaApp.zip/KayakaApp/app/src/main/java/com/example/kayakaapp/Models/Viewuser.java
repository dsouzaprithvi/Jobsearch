package com.example.kayakaapp.Models;

public class Viewuser {

    String amount, message, status, username, usernumber, userprofilepic;

    public Viewuser() {
    }

    public Viewuser(String amount, String message, String status, String username, String usernumber, String userprofilepic) {
        this.amount = amount;
        this.message = message;
        this.status = status;
        this.username = username;
        this.usernumber = usernumber;
        this.userprofilepic = userprofilepic;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsernumber() {
        return usernumber;
    }

    public void setUsernumber(String usernumber) {
        this.usernumber = usernumber;
    }

    public String getUserprofilepic() {
        return userprofilepic;
    }

    public void setUserprofilepic(String userprofilepic) {
        this.userprofilepic = userprofilepic;
    }

}
