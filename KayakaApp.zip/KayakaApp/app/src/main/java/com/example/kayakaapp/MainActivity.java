package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.kayakaapp.Fragments.Addpostfragment;
import com.example.kayakaapp.Fragments.Appliedfragment;
import com.example.kayakaapp.Fragments.Chatsfragment;
import com.example.kayakaapp.Fragments.Homefragment;
import com.example.kayakaapp.Fragments.Yourpostfragment;
import com.example.kayakaapp.Models.Userdetailsmodel;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {

    ImageView profilepic;
    TextView loactionsetting;

    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        profilepic = findViewById(R.id.profile_pic);
        loactionsetting = findViewById(R.id.location_setting);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        database.getReference().child("Users").child(auth.getCurrentUser().getPhoneNumber())
                        .child("Userdetails").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Userdetailsmodel users = snapshot.getValue(Userdetailsmodel.class);
                        Picasso.get().load(users.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });



        database.getReference().child("Users").child(auth.getCurrentUser().getPhoneNumber())
                .child("address").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String location = "";
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            if (dataSnapshot.getKey().equals("fulladdress")) {

                            } else {
                                loactionsetting.setText(dataSnapshot.getValue(String.class));
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        profilepic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Userprofile.class));
            }
        });

        loactionsetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Locationsetting.class));
            }
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(navlistner);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new Homefragment()).commit();


    }

//    @Override
//    public void onBackPressed() {
//        super.onBackPressed();
//        finish();
//        System.exit(0);
//    }

    public Bundle getMyData() {
        Bundle bundle = new Bundle();
        bundle.putString("Pincode", loactionsetting.getText().toString());
        return bundle;
    }

    private NavigationBarView.OnItemSelectedListener navlistner =
            new NavigationBarView.OnItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selected_fragment = null;

                    switch(item.getItemId()){

                        case R.id.home:
                            selected_fragment = new Homefragment();
                            break;

                        case R.id.applied:
                            selected_fragment = new Appliedfragment();
                            break;

                        case R.id.chats:
                            selected_fragment = new Chatsfragment();
                            break;

                        case R.id.add_post:
                            selected_fragment = new Addpostfragment();
                            break;

                        case R.id.your_post:
                            selected_fragment = new Yourpostfragment();
                            break;

                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            selected_fragment).commit();

                    return true;

                }
            };


}