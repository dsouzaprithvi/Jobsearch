package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.kayakaapp.Fragments.Addpostfragment;
import com.example.kayakaapp.Fragments.Appliedfragment;
import com.example.kayakaapp.Fragments.Chatsfragment;
import com.example.kayakaapp.Fragments.Homefragment;
import com.example.kayakaapp.Fragments.Yourpostfragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    ImageView profilepic;
    TextView loactionsetting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        profilepic = findViewById(R.id.profile_pic);
        loactionsetting = findViewById(R.id.location_setting);

        profilepic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Userprofile.class));
            }
        });

        loactionsetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Locationsetting.class));
            }
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(navlistner);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new Homefragment()).commit();


    }

    private BottomNavigationView.OnNavigationItemSelectedListener navlistner =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selected_fragment = null;

                    switch(item.getItemId()){

                        case R.id.home:
                            selected_fragment = new Homefragment();
                            break;

                        case R.id.applied:
                            selected_fragment = new Appliedfragment();
                            break;

                        case R.id.chats:
                            selected_fragment = new Chatsfragment();
                            break;

                        case R.id.add_post:
                            selected_fragment = new Addpostfragment();
                            break;

                        case R.id.your_post:
                            selected_fragment = new Yourpostfragment();
                            break;

                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            selected_fragment).commit();

                    return true;


                }
            };
}