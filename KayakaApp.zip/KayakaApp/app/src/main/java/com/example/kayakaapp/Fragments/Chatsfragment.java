package com.example.kayakaapp.Fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.kayakaapp.Adapters.Usersadapter;
import com.example.kayakaapp.Models.Userdetailsmodel;
import com.example.kayakaapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class Chatsfragment extends Fragment {

    FirebaseAuth auth;
    FirebaseDatabase database;

    ArrayList<Userdetailsmodel> usersholder;
    ArrayList<Userdetailsmodel> usersholder1 = new ArrayList<>();
    Usersadapter adapter;
    RecyclerView recyclerView;


    public Chatsfragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_chatsfragment, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        usersholder = new ArrayList<>();
        adapter = new Usersadapter(getContext(), usersholder);
        recyclerView.setAdapter(adapter);

        loaddata();


        return view;
    }

    private void loadchats() {

        String id = auth.getCurrentUser().getUid();
        database.getReference().child("Recentchats")
                .child(id)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        usersholder.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            for ( int i = 0; i<usersholder1.size(); i++ ) {
                                if ( usersholder1.get(i).getId().equals(dataSnapshot.getKey())) {
                                    Log.i("Usersrs=---->",usersholder1.get(i).getId());
                                    usersholder.add(usersholder1.get(i));
                                }
                            }
                        }
                        Collections.sort(usersholder, new Comparator<Userdetailsmodel>() {
                            @Override
                            public int compare(Userdetailsmodel users, Userdetailsmodel t1) {
                                return users.getName().compareToIgnoreCase(t1.getName());
                            }
                        });
                        adapter.notifyDataSetChanged();

                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }

    private void loaddata () {

        String id = auth.getCurrentUser().getPhoneNumber();

        database.getReference().child("Users").
                addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        usersholder1.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                            if (dataSnapshot.getKey().equals(id)) {
                                continue;
                            } else {
                                for (DataSnapshot child : dataSnapshot.getChildren()) {
                                    if (child.getKey().equals("Userdetails")) {
                                        usersholder1.add(child.getValue(Userdetailsmodel.class));
                                    }
                                }
                            }
                        }
                        loadchats();
//                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }
}