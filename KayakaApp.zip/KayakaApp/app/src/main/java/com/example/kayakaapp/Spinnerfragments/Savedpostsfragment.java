package com.example.kayakaapp.Spinnerfragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.kayakaapp.Adapters.Postadapter;
import com.example.kayakaapp.Adapters.Usersadapter;
import com.example.kayakaapp.Models.Postsmodel;
import com.example.kayakaapp.Models.Userdetailsmodel;
import com.example.kayakaapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class Savedpostsfragment extends Fragment {


    ArrayList<Postsmodel> postholder;
    Postadapter adapter;
    RecyclerView recyclerView;


    FirebaseAuth auth;
    FirebaseDatabase database;
    
    
    public Savedpostsfragment() {
        // Required empty public constructor
    }
    

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_savedpostsfragment, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        postholder = new ArrayList<>();
        adapter = new Postadapter(getContext(), postholder);
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new Postadapter.OnItemClickListener() {
            @Override
            public void onCardviewclick(int position) {

            }

            @Override
            public void onEditClick(int position) {

            }

            @Override
            public void onDeleteClick(int position) {
                removeItem(position);
            }
        });



        loaddata();
        
        return view;
    }

    private void loaddata() {

        String id = auth.getCurrentUser().getPhoneNumber();

        database.getReference().child("Users").child(id).child("Savedposts")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                postholder.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Log.i("Post sadoaida->",child.getKey());
                    Postsmodel postsmodel = child.getValue(Postsmodel.class);
                    postholder.add(postsmodel);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void removeItem(int position){
        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setIcon(R.drawable.ic_baseline_warning_24)
                .setTitle("Delete")
                .setMessage("Are you sure to delete")
                .setPositiveButton("OK", null)
                .setNegativeButton("Cancel", null)
                .show();

        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        positiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String date = postholder.get(position).getDatetime();
                postholder.remove(position);
                adapter.notifyItemRemoved(position);
                String id = auth.getCurrentUser().getPhoneNumber();
                database.getReference().child("Users").child(id).child("Savedposts").child(date).removeValue();
                dialog.dismiss();
            }
        });
    }
}