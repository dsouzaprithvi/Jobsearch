package com.example.kayakaapp.Spinnerfragments;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kayakaapp.Adapters.Postviewadapter;
import com.example.kayakaapp.MainActivity;
import com.example.kayakaapp.Models.Postsmodel;
import com.example.kayakaapp.Models.Userdetailsmodel;
import com.example.kayakaapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;


public class Completedappliedfragment extends Fragment {

    ArrayList<Postsmodel> postholder;
    Postviewadapter adapter;
    RecyclerView recyclerView;

    Userdetailsmodel userdata;

    FirebaseAuth auth;
    FirebaseDatabase database;

    String pincode;
    int urpin;

    public Completedappliedfragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_completedappliedfragment, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        postholder = new ArrayList<>();
        adapter = new Postviewadapter(getContext(), postholder);
        recyclerView.setAdapter(adapter);

        loaddata();

        return view;
    }

    private void loaddata() {

        String phone = auth.getCurrentUser().getPhoneNumber();

        database.getReference().child("Posts")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        postholder.clear();
                        for (DataSnapshot pincode : snapshot.getChildren()) {
                            String pin = pincode.getKey();
                            for (DataSnapshot postid : pincode.getChildren()) {
                                String mob = postid.getKey();
                                for (DataSnapshot date : postid.getChildren()) {
                                    String day = date.getKey();
                                    for (DataSnapshot getrequest : date.getChildren()) {
                                        if (getrequest.getKey().equals("ApplyRequest")) {
                                            for (DataSnapshot getuser : getrequest.getChildren()) {
                                                if (getuser.getKey().equals(phone)) {
                                                    getpost(pin, mob, day);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
//                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void getpost(String pin, String mob, String day) {
        database.getReference().child("Posts")
                .child(pin)
                .child(mob)
                .child(day)
                .child("Postdetails")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Postsmodel posts = snapshot.getValue(Postsmodel.class);
                        if ( posts.getStatus().equals("Completed") ) {
                            postholder.add(posts);
                        }
                        adapter.notifyDataSetChanged();
                        adapter.setOnLongClickListener(new Postviewadapter.OnItemLongClickListener() {
                            @Override
                            public void onLongClick(int position) {
                                removeItem(position);
                            }
                        });
                        adapter.setOnItemClickListener(new Postviewadapter.OnItemClickListener() {
                            @Override
                            public void onCardviewclick(int position) {
                                rateuser(position);

                            }
                        });
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    public void rateuser(int position) {

        database.getReference().child("Users").child(postholder.get(position).getPhonenumber())
                .child("Userdetails").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        userdata = snapshot.getValue(Userdetailsmodel.class);
                        onButtonShowPopupWindowClick();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

//        onButtonShowPopupWindowClick(getView());

    }

    public void onButtonShowPopupWindowClick (){

        // inflate the layout of the popup window

//        LayoutInflater inflater = (LayoutInflater)
//                getActivity().getSystemService(LAYOUT_INFLATER_SERVICE);
//        View popupView = inflater.inflate(R.layout.layout_bottom_sheet_password, null);
////        Drawable background = ContextCompat.getDrawable(Settings.this, R.drawable.res_black_menuroundfilled_corner);
//        popupView.setBackground(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//
//        // create the popup window
//        int width = LinearLayout.LayoutParams.MATCH_PARENT;
//        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
//        boolean focusable = true; // lets taps outside the popup also dismiss it
//        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
//
//        // show the popup window
//        // which view you pass in doesn't matter, it is only used for the window tolken
//        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
//
//        // dismiss the popup window when touched
//        popupView.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                popupWindow.dismiss();
//                return true;
//            }
//        });

        Dialog builder = new Dialog(getContext());
        builder.requestWindowFeature(Window.FEATURE_NO_TITLE);
        builder.setCancelable(true);
        builder.setContentView(R.layout.rate_user);
        ImageView profile = builder.findViewById(R.id.profile_pic);
        TextView username = builder.findViewById(R.id.user_name);
        RatingBar ratingBar = builder.findViewById(R.id.rating);
        Button update = builder.findViewById(R.id.update);
        Picasso.get().load(userdata.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profile);
        username.setText(userdata.getName());

        builder.getWindow().setBackgroundDrawable(
                new ColorDrawable(android.graphics.Color.TRANSPARENT));
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
            }
        });
        builder.show();

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String rate = String.valueOf(ratingBar.getRating());
                database.getReference().child("Users").child(userdata.getPhonenumber())
                        .child("Userdetails").child("rating").setValue(rate);
                builder.dismiss();
                Toast.makeText(getContext(), "Rated successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getContext(), MainActivity.class));
                getActivity().finish();
            }
        });

    }



    public void removeItem(int position) {
        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setIcon(R.drawable.ic_baseline_warning_24)
                .setTitle("Delete")
                .setMessage("Are you sure to delete the applied post")
                .setPositiveButton("OK", null)
                .setNegativeButton("Cancel", null)
                .show();

        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        positiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pin = postholder.get(position).getPincode();
                String mobnumber = postholder.get(position).getPhonenumber();
                String date = postholder.get(position).getDatetime();
                postholder.remove(position);
                adapter.notifyItemRemoved(position);
                database.getReference().child("Posts")
                        .child(pin)
                        .child(mobnumber)
                        .child(date)
                        .child("ApplyRequest")
                        .child(auth.getCurrentUser().getPhoneNumber())
                        .removeValue();
                dialog.dismiss();
            }
        });
    }

}