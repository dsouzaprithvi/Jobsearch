package com.example.kayakaapp.Models;

public class Postsmodel {


    String jobtype, title, description, category, location, payment, startpay, endpay,
    payas, cash, status, datetime, requests, pincode, phonenumber;


    public Postsmodel() {
    }

    public Postsmodel(String jobtype, String title,
                      String description, String category,
                      String location, String pincode,
                      String payment,
                      String startpay, String endpay,
                      String payas, String cash,
                      String status, String datetime,
                      String requests, String phonenumber) {
        this.jobtype = jobtype;
        this.title = title;
        this.description = description;
        this.category = category;
        this.location = location;
        this.payment = payment;
        this.startpay = startpay;
        this.endpay = endpay;
        this.payas = payas;
        this.cash = cash;
        this.status = status;
        this.datetime = datetime;
        this.requests = requests;
        this.phonenumber = phonenumber;
    }

    public Postsmodel(String jobtype, String title,
                      String description, String category,
                      String location, String pincode,
                      String payment,
                      String startpay, String endpay,
                      String payas, String cash,
                      String status, String datetime, String phonenumber) {
        this.jobtype = jobtype;
        this.title = title;
        this.description = description;
        this.category = category;
        this.location = location;
        this.pincode = pincode;
        this.payment = payment;
        this.startpay = startpay;
        this.endpay = endpay;
        this.payas = payas;
        this.cash = cash;
        this.status = status;
        this.datetime = datetime;
        this.phonenumber = phonenumber;

    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getRequests() {
        return requests;
    }

    public void setRequests(String requests) {
        this.requests = requests;
    }

    public String getJobtype() {
        return jobtype;
    }

    public void setJobtype(String jobtype) {
        this.jobtype = jobtype;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getStartpay() {
        return startpay;
    }

    public void setStartpay(String startpay) {
        this.startpay = startpay;
    }

    public String getEndpay() {
        return endpay;
    }

    public void setEndpay(String endpay) {
        this.endpay = endpay;
    }

    public String getPayas() {
        return payas;
    }

    public void setPayas(String payas) {
        this.payas = payas;
    }

    public String getCash() {
        return cash;
    }

    public void setCash(String cash) {
        this.cash = cash;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }
}
