package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kayakaapp.Models.Userdetailsmodel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Set;

import de.hdodenhof.circleimageview.CircleImageView;

public class Settings extends AppCompatActivity {

    TextView editprofile, changepassword, mailus, deleteaccount, logout, username, phonenumber;
    String phone;
    CircleImageView profilepic;
    Button back;

    FirebaseAuth auth;
    FirebaseDatabase database;

    Userdetailsmodel userdetailsmodel;
    String location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        editprofile = findViewById(R.id.edit_profile);
        changepassword = findViewById(R.id.change_password);
        mailus = findViewById(R.id.mail_us);
        deleteaccount = findViewById(R.id.delete_account);
        logout = findViewById(R.id.logout);
        username = findViewById(R.id.user_name);
        phonenumber = findViewById(R.id.phone_number);
        profilepic = findViewById(R.id.profile_pic);
        back = findViewById(R.id.back_button);


        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        phone = auth.getCurrentUser().getPhoneNumber();
        database.getReference().child("Users").child(phone)
                .child("Userdetails")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userdetailsmodel = snapshot.getValue(Userdetailsmodel.class);
                Picasso.get().load(userdetailsmodel.getProfilepic())
                        .placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
                username.setText(userdetailsmodel.getName());
                phonenumber.setText(phone);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        database.getReference().child("Users").child(auth.getCurrentUser().getPhoneNumber())
                .child("address").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            if (dataSnapshot.getKey().equals("fulladdress")) {

                            } else {
                                location = dataSnapshot.getValue(String.class);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        deleteaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomdelete();
//                onButtonShowPopupWindowClick(view);
            }
        });

        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Settings.this, Editprofile.class));
            }
        });

        changepassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Settings.this, Changepassword.class));
            }
        });

        mailus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Settings.this, Emailus.class));
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                auth.signOut();
                startActivity(new Intent(Settings.this, Loginscreen.class));
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void bottomdelete() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(
                Settings.this, R.style.BottomSheetDialogTheme
        );
        View bottomSheetView = LayoutInflater.from(getApplicationContext())
                .inflate(R.layout.layout_bottom_sheet,
                        (LinearLayout)findViewById(R.id.bottomsheetcontainer));
        bottomSheetView.findViewById(R.id.yes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                database.getReference().child("Users").child(auth.getCurrentUser().getPhoneNumber()).removeValue();
//                database.getReference().child("Posts").child(location).child(auth.getCurrentUser().getPhoneNumber()).removeValue();
//                auth.signOut();
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//                Toast.makeText(Settings.this, user.toString(), Toast.LENGTH_SHORT).show();

                user.delete()
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(Settings.this, "User account deleted.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                bottomSheetDialog.dismiss();

            }
        });
        bottomSheetView.findViewById(R.id.no).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();
    }

    private void bottomview() {
        final BottomSheetDialog bottomSheetDialogpass = new BottomSheetDialog(
                Settings.this, R.style.BottomSheetStyle

        );
        View bottomsheetviewpass = LayoutInflater.from(getApplicationContext())
                .inflate(R.layout.layout_bottom_sheet_password,
                        (LinearLayout)findViewById(R.id.bottomsheetcontainerpassword));
        bottomSheetDialogpass.setContentView(bottomsheetviewpass);
        bottomSheetDialogpass.show();
    }

    public void onButtonShowPopupWindowClick (View view){

        // inflate the layout of the popup window

        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.layout_bottom_sheet_password, null);
//        Drawable background = ContextCompat.getDrawable(Settings.this, R.drawable.res_black_menuroundfilled_corner);
//        popupView.setBackground(background);

        // create the popup window
        int width = LinearLayout.LayoutParams.MATCH_PARENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

        // dismiss the popup window when touched
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                popupWindow.dismiss();
                return true;
            }
        });
    }

}