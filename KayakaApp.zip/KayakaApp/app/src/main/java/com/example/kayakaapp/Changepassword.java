package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.kayakaapp.Models.Userdetailsmodel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Changepassword extends AppCompatActivity {

    TextInputLayout currentpassword, newpassword, confirmpassword;
    MaterialButton update;
    String password;


    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changepassword);


        currentpassword = findViewById(R.id.current_password);
        newpassword = findViewById(R.id.new_password);
        confirmpassword = findViewById(R.id.confirm_password);
        update = findViewById(R.id.update);


        auth  = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validate_text(currentpassword) | !validate_text(newpassword) |
                        !validate_text(confirmpassword)) {
                    return;
                }
                String phone = auth.getCurrentUser().getPhoneNumber();
                database.getReference().child("Users").child(phone).child("Userdetails")
                        .addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                Userdetailsmodel userdetailsmodel = snapshot.getValue(Userdetailsmodel.class);
                                if (currentpassword.getEditText().getText().toString().equals(userdetailsmodel.getPassword())) {
                                    if (!validate_password()) {
                                        return;
                                    }
                                    database.getReference().child("Users").child(phone)
                                            .child("Userdetails").child("password")
                                            .setValue(newpassword.getEditText().getText().toString());
                                    Toast.makeText(Changepassword.this, "Password updated", Toast.LENGTH_SHORT).show();
                                } else {
                                    currentpassword.setError("Current password does not match");
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });

            }
        });
    }


    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }


    private boolean validate_password(){
        String pass = newpassword.getEditText().getText().toString();
        String cpass = confirmpassword.getEditText().getText().toString();
        if (pass.equals(cpass)){
            confirmpassword.setError(null);
            confirmpassword.setErrorEnabled(false);
            return true;
        } else {
            confirmpassword.setError("Password does not match");
            return false;
        }
    }
}