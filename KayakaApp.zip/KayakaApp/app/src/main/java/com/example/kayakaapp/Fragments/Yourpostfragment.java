package com.example.kayakaapp.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.kayakaapp.MainActivity;
import com.example.kayakaapp.R;
import com.example.kayakaapp.Spinnerfragments.Activepostsfragment;
import com.example.kayakaapp.Spinnerfragments.Completedfragment;
import com.example.kayakaapp.Spinnerfragments.Inprogressfragment;
import com.example.kayakaapp.Spinnerfragments.Savedpostsfragment;

import java.util.ArrayList;
import java.util.List;


public class Yourpostfragment extends Fragment {


    public Yourpostfragment() {
        // Required empty public constructor
    }


    Activepostsfragment activepostsfragment;
    Completedfragment completedfragment;
    Inprogressfragment inprogressfragment;
    Savedpostsfragment savedpostsfragment;

    Spinner spinner;

    List<String> names;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_yourpostfragment, container, false);

        spinner = view.findViewById(R.id.spinner);

        activepostsfragment = new Activepostsfragment();
        completedfragment = new Completedfragment();
        inprogressfragment = new Inprogressfragment();
        savedpostsfragment = new Savedpostsfragment();

        names = new ArrayList<>();
        names.add("Active Posts");
        names.add("Completed Posts");
        names.add("In progress Posts");
        names.add("Saved Posts");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getContext(), R.layout.item, names);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0 :
                        selectfragment(activepostsfragment);
                        break;
                    case 1 :
                        selectfragment(completedfragment);
                        break;
                    case 2 :
                        selectfragment(inprogressfragment);
                        break;
                    case 3 :
                        selectfragment(savedpostsfragment);
                        break;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        return  view;
    }

    private  void selectfragment(Fragment fragment){

        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }
}