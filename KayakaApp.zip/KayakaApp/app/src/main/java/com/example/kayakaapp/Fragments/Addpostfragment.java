package com.example.kayakaapp.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import com.example.kayakaapp.R;


public class Addpostfragment extends Fragment {


    AutoCompleteTextView jobcategory;
    ArrayAdapter<String> adapterjobcategory;
    String[] jobcategories;



    public Addpostfragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_addpostfragment, container, false);




        jobcategories = new String[]{"Housekeeping" , "Grocery Shopping", "Elderly care",
                "Electrician", "Driver", "Computer and TV repair", "AC Mechanic", "Others"};
        jobcategory = (AutoCompleteTextView) view.findViewById(R.id.job_category);
        adapterjobcategory = new ArrayAdapter<String>(getContext(), R.layout.list_item,jobcategories);
        jobcategory.setAdapter(adapterjobcategory);





        return view;
    }
}