package com.example.kayakaapp.Fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.Toast;

import com.example.kayakaapp.Models.Postsmodel;
import com.example.kayakaapp.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class Addpostfragment extends Fragment {


    AutoCompleteTextView jobcategory;
    ArrayAdapter<String> adapterjobcategory;
    String[] jobcategories;

    MaterialButton save, post;
    TextInputLayout jobtitle, jobdescription, joblocation, pincode, startpay, endpay;

    RadioButton radioButton, createjob, needjob, fixed, range, perhour, perday, lumpsum,
    yes, no;
    RadioGroup jobtype, paymentype, payas, paymentmethod;

    FirebaseAuth auth;
    FirebaseDatabase database;

    String phone, currentdatetime, Pincode;


    public Addpostfragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_addpostfragment, container, false);

        createjob = view.findViewById(R.id.create_job);
        needjob = view.findViewById(R.id.need_job);
        fixed = view.findViewById(R.id.fixed);
        range = view.findViewById(R.id.range);
        perhour = view.findViewById(R.id.perhour);
        perday = view.findViewById(R.id.perday);
        lumpsum = view.findViewById(R.id.lumpsum);
        yes = view.findViewById(R.id.yes);
        no = view.findViewById(R.id.no);
        save = view.findViewById(R.id.save);
        post = view.findViewById(R.id.post);
        jobtitle = view.findViewById(R.id.job_title);
        jobdescription = view.findViewById(R.id.job_description);
        joblocation = view.findViewById(R.id.job_location);
        pincode = view.findViewById(R.id.pincode);
        startpay = view.findViewById(R.id.start_pay);
        endpay = view.findViewById(R.id.end_pay);
        jobtype = view.findViewById(R.id.job_type);
        paymentype = view.findViewById(R.id.payment_type);
        payas = view.findViewById(R.id.pay_as);
        paymentmethod = view.findViewById(R.id.payment_method);


        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        phone =  auth.getCurrentUser().getPhoneNumber();


        jobcategories = new String[]{"Housekeeping" , "Grocery Shopping", "Elderly care",
                "Electrician", "Driver", "Computer and TV repair", "AC Mechanic", "Others"};
        jobcategory = (AutoCompleteTextView) view.findViewById(R.id.job_category);
        adapterjobcategory = new ArrayAdapter<String>(getContext(), R.layout.list_item,jobcategories);
        jobcategory.setAdapter(adapterjobcategory);

        database.getReference().child("Users/"+auth.getCurrentUser().getPhoneNumber()+"/address/pincode")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Pincode = snapshot.getValue(String.class);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!(createjob.isChecked() || needjob.isChecked()) |
                        !(fixed.isChecked() || range.isChecked()) |
                        !(perday.isChecked() || perhour.isChecked() || lumpsum.isChecked()) |
                        !(yes.isChecked() || no.isChecked())) {
                    Toast.makeText(getContext(), "Field not selected", Toast.LENGTH_SHORT).show();
                    return;
                }

                if ( !validate(jobtitle) | !validate(jobdescription) | !validate(joblocation) |
                        !validate(pincode) | !validate(startpay) | !validate(endpay) ) {
                    return;
                }



                currentdatetime = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss", Locale.getDefault()).format(new Date());
                String job_type, payment_type, pay_as, pay_by_cash;
                job_type = radiobuttonlistener(jobtype);
                payment_type = radiobuttonlistener(paymentype);
                pay_as = radiobuttonlistener(payas);
                pay_by_cash = radiobuttonlistener(paymentmethod);
                Postsmodel postsmodel = new Postsmodel(job_type, jobtitle.getEditText().getText().toString(),
                        jobdescription.getEditText().getText().toString(), job_type, joblocation.getEditText().getText().toString(),
                        pincode.getEditText().getText().toString(),
                        payment_type, startpay.getEditText().getText().toString(), endpay.getEditText().getText().toString(),
                        pay_as, pay_by_cash, "Activepost", currentdatetime, phone);
                database.getReference().child("Posts").child(pincode.getEditText().getText().toString()).child(auth.getCurrentUser().getPhoneNumber())
                        .child(currentdatetime).child("Postdetails").setValue(postsmodel);
                database.getReference().child("Users").child(phone).child("Savedposts").child(currentdatetime)
                        .setValue(postsmodel);
                Toast.makeText(getContext(), "Posted Successfully", Toast.LENGTH_SHORT).show();
            }
        });


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!(createjob.isChecked() || needjob.isChecked()) |
                        !(fixed.isChecked() || range.isChecked()) |
                        !(perday.isChecked() || perhour.isChecked() || lumpsum.isChecked()) |
                        !(yes.isChecked() || no.isChecked())) {
                    Toast.makeText(getContext(), "Field not selected", Toast.LENGTH_SHORT).show();
                    return;
                }

                if ( !validate(jobtitle) | !validate(jobdescription) | !validate(joblocation) |
                        !validate(pincode) | !validate(startpay) | !validate(endpay) ) {
                    return;
                }



                currentdatetime = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss", Locale.getDefault()).format(new Date());
                String job_type, payment_type, pay_as, pay_by_cash;
                job_type = radiobuttonlistener(jobtype);
                payment_type = radiobuttonlistener(paymentype);
                pay_as = radiobuttonlistener(payas);
                pay_by_cash = radiobuttonlistener(paymentmethod);
                Postsmodel postsmodel = new Postsmodel(job_type, jobtitle.getEditText().getText().toString(),
                        jobdescription.getEditText().getText().toString(), job_type, joblocation.getEditText().getText().toString(),
                        pincode.getEditText().getText().toString(),
                        payment_type, startpay.getEditText().getText().toString(), endpay.getEditText().getText().toString(),
                        pay_as, pay_by_cash, "Saved", currentdatetime, phone);
                database.getReference().child("Users").child(phone).child("Savedposts").child(currentdatetime)
                        .setValue(postsmodel);
                Toast.makeText(getContext(), "Post Saved", Toast.LENGTH_SHORT).show();
            }
        });




        return view;
    }

    private String radiobuttonlistener(RadioGroup radioGroup) {
        int selectID = radioGroup.getCheckedRadioButtonId();
        radioButton = getView().findViewById(selectID);
        return radioButton.getText().toString();
    }



    private boolean validate(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }
}