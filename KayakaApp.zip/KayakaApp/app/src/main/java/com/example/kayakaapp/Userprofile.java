package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.kayakaapp.Models.Userdetailsmodel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Userprofile extends AppCompatActivity {


    TextView editprofile, settings, logout, username, phonenumber;
    String phone;
    CircleImageView profilepic;
    Button back;
    RatingBar ratingBar;


    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);

        editprofile = findViewById(R.id.edit_profile);
        settings = findViewById(R.id.settings);
        logout = findViewById(R.id.logout);
        username = findViewById(R.id.user_name);
        phonenumber = findViewById(R.id.phone_number);
        profilepic = findViewById(R.id.profile_pic);
        back = findViewById(R.id.back_button);
        ratingBar = findViewById(R.id.rating);


        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        phone = auth.getCurrentUser().getPhoneNumber();
        database.getReference().child("Users").child(phone).child("Userdetails")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Userdetailsmodel userdetailsmodel = snapshot.getValue(Userdetailsmodel.class);
                        Picasso.get().load(userdetailsmodel.getProfilepic())
                                .placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
                        username.setText(userdetailsmodel.getName());
                        phonenumber.setText(phone);
                        try {
                            ratingBar.setRating(Float.parseFloat(userdetailsmodel.getRating()));
                        } catch (NullPointerException e) {

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Userprofile.this, Editprofile.class));
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Userprofile.this, Settings.class));
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                auth.signOut();
                startActivity(new Intent(Userprofile.this, Loginscreen.class));
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}