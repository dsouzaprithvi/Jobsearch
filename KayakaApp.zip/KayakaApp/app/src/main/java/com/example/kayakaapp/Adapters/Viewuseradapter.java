package com.example.kayakaapp.Adapters;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kayakaapp.Chatscreen;
import com.example.kayakaapp.Models.Applymodel;
import com.example.kayakaapp.Models.Userdetailsmodel;
import com.example.kayakaapp.Models.Viewuser;
import com.example.kayakaapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class Viewuseradapter extends RecyclerView.Adapter<Viewuseradapter.MyViewholder> {

    Context context;
    ArrayList<Applymodel> usersholder;

    private OnItemClickListener mListener;

    public interface OnItemClickListener {

//        void onEditClick(int position);

        void onCardviewclick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public Viewuseradapter(Context context, ArrayList<Applymodel> usersholder) {
        this.context = context;
        this.usersholder = usersholder;
    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_chat, parent, false);
        return new MyViewholder(view, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {

        Applymodel data = usersholder.get(position);

        Picasso.get().load(data.getUserprofilepic()).placeholder(R.drawable.ic_baseline_person_24).into(holder.profilepic);


        holder.name.setText(data.getUsername());
//        holder.lastmessage.setText(data.getLastmessage());
//        holder.date.setText(data.getDate());


        holder.profilepic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog builder = new Dialog(context);
                builder.requestWindowFeature(Window.FEATURE_NO_TITLE);
                builder.setCancelable(true);
                builder.setContentView(R.layout.view_profile_pic);
                ImageView imageView = builder.findViewById(R.id.profile);
                Picasso.get().load(data.getUserprofilepic()).placeholder(R.drawable.ic_baseline_person_24).into(imageView);
                builder.getWindow().setBackgroundDrawable(
                        new ColorDrawable(android.graphics.Color.TRANSPARENT));
                builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialogInterface) {
                    }
                });

//                ImageView imageView = new ImageView(context);
//                Uri imageUri;
//                Picasso.get().load(data.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(imageView);
//                builder.addContentView(imageView, new RelativeLayout.LayoutParams(
//                        ViewGroup.LayoutParams.WRAP_CONTENT,
//                        ViewGroup.LayoutParams.WRAP_CONTENT));
                builder.show();


            }

        });
    }

    @Override
    public int getItemCount() {
        return usersholder.size();
    }

    public class MyViewholder extends RecyclerView.ViewHolder {

        CircleImageView profilepic;
        TextView name, lastmessage, date;
        CardView cardView;

        public MyViewholder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);

            profilepic = itemView.findViewById(R.id.profile_pic);
            name = itemView.findViewById(R.id.user_name);
            cardView = itemView.findViewById(R.id.cardview);
//            lastmessage = itemView.findViewById(R.id.last_message);
//            date = itemView.findViewById(R.id.date);

            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onCardviewclick(position);
                        }
                    }
                }
            });
        }
    }
}
