package com.example.kayakaapp.Fragments;

import android.app.DownloadManager;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.kayakaapp.R;
import com.example.kayakaapp.Spinnerfragments.Completedappliedfragment;
import com.example.kayakaapp.Spinnerfragments.Completedfragment;
import com.example.kayakaapp.Spinnerfragments.Inprogressappliedfragment;
import com.example.kayakaapp.Spinnerfragments.Requestpendingfragment;

import java.util.ArrayList;
import java.util.List;


public class Appliedfragment extends Fragment {


    public Appliedfragment() {
        // Required empty public constructor
    }

    Requestpendingfragment requestpendingfragment;
    Inprogressappliedfragment inprogressappliedfragment;
    Completedappliedfragment completedappliedfragment;

    Spinner spinner;

    List<String> names;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_appliedfragment, container, false);

        spinner = view.findViewById(R.id.spinner);

        requestpendingfragment = new Requestpendingfragment();
        inprogressappliedfragment = new Inprogressappliedfragment();
        completedappliedfragment = new Completedappliedfragment();

        names = new ArrayList<>();
        names.add("Applied Post");
        names.add("Completed Post");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getContext(), R.layout.item, names);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0 :
                        selectfragment(requestpendingfragment);
                        break;
                    case 1 :
                        selectfragment(completedappliedfragment);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        return view;
    }

    private  void selectfragment(Fragment fragment){

        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }
}