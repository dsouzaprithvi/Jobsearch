package com.example.kayakaapp.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.kayakaapp.Adapters.Postadapter;
import com.example.kayakaapp.Adapters.Postviewadapter;
import com.example.kayakaapp.Locationsetting;
import com.example.kayakaapp.Models.Postsmodel;
import com.example.kayakaapp.R;
import com.example.kayakaapp.Userprofile;
import com.example.kayakaapp.Viewpostandapply;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class Homefragment extends Fragment {

    ArrayList<Postsmodel> postholder;
    Postviewadapter adapter;
    RecyclerView recyclerView;


    FirebaseAuth auth;
    FirebaseDatabase database;

    String pincode;
    int urpin;



    public Homefragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_homefragment, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        postholder = new ArrayList<>();
        adapter = new Postviewadapter(getContext(), postholder);
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new Postviewadapter.OnItemClickListener() {
            @Override
            public void onCardviewclick(int position) {
                Intent intent = new Intent(getContext(), Viewpostandapply.class);
                Gson gson = new Gson();
                String myJson = gson.toJson(postholder.get(position));
                intent.putExtra("Postdata", myJson);
                startActivity(intent);
            }
        });


        loaddata();


        return view;
    }

    private void loaddata() {

        String phonenumber = auth.getCurrentUser().getPhoneNumber();
        database.getReference()
                .child("Users/"+phonenumber+"/address/pincode")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                try {
                    postholder.clear();
                    pincode = snapshot.getValue(String.class);
                    urpin = Integer.parseInt(pincode);
                    database.getReference().child("Posts")
                            .addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                        int pin = Integer.parseInt(dataSnapshot.getKey());
//                            if ( (urpin-100 < pin) || (pin > urpin-100) ) {
//                                Log.i("Pincode", String.valueOf(pin));
//                            }
                                        if ( (urpin-100 <= pin) && (pin <= urpin+100 )) {
                                            Log.i("Pincode", String.valueOf(pin));
                                            for (DataSnapshot child : dataSnapshot.getChildren()) {
                                                for (DataSnapshot posts : child.getChildren()) {
                                                    for (DataSnapshot postdetails : posts.getChildren()) {
                                                        if (postdetails.getKey().equals("Postdetails")) {
                                                            Postsmodel postsmodel = postdetails.getValue(Postsmodel.class);
                                                            if (postsmodel.getStatus().equals("Activepost")) {
                                                                postholder.add(postsmodel);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    //Sorting recyclerview
                                    Collections.sort(postholder, new Comparator<Postsmodel>() {
                                        @Override
                                        public int compare(Postsmodel p1, Postsmodel p2) {
                                            return p2.getDatetime().compareToIgnoreCase(p1.getDatetime());
                                        }
                                    });
                                    adapter.notifyDataSetChanged();
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                } catch (Exception e) {

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }
}