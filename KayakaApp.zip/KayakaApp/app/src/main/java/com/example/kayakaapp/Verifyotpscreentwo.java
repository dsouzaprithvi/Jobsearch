package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kayakaapp.Models.Userdetailsmodel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Verifyotpscreentwo extends AppCompatActivity {

    TextView phonenumber, resendotp, resendotptext, timerview;
    TextInputLayout otp;
    ProgressBar progressBar;
    MaterialButton verifyotp;
    String name, phone, password, getotpbackend;

    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifyotpscreentwo);

        phonenumber = findViewById(R.id.phone_number);
        otp = findViewById(R.id.otp);
        progressBar = findViewById(R.id.progressbar_verify_otp);
        verifyotp = findViewById(R.id.verifyotp);
        resendotp = findViewById(R.id.resend_otp);
        resendotptext = findViewById(R.id.resend_otp_text);
        timerview = findViewById(R.id.timerview);


        name = getIntent().getStringExtra("Name");
        phone = getIntent().getStringExtra("Phonenumber");
        password = getIntent().getStringExtra("Password");


        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        phonenumber.setText(phone);


        initiateotp();
        timerfunction();


        verifyotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (!otp.getEditText().getText().toString().isEmpty()) {
                    String enterotp = otp.getEditText().getText().toString();


                    if( getotpbackend != null) {
                        progressBar.setVisibility(View.VISIBLE);
                        verifyotp.setVisibility(View.INVISIBLE);
                        Log.i("otp ", getotpbackend);
                        PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(getotpbackend, enterotp);
                        signInWithPhoneAuthCredential(phoneAuthCredential);
                    } else {
                        Toast.makeText(Verifyotpscreentwo.this, "Please check Internet connection", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(Verifyotpscreentwo.this, "Please enter the otp", Toast.LENGTH_SHORT).show();
                }
            }
        });

        resendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resendotp.setVisibility(View.GONE);
                resendotptext.setVisibility(View.VISIBLE);
                timerfunction();

                PhoneAuthProvider.verifyPhoneNumber(PhoneAuthOptions.newBuilder(auth).setPhoneNumber(phone)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(Verifyotpscreentwo.this)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                Toast.makeText(Verifyotpscreentwo.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCodeSent(@NonNull String newbackendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                getotpbackend = newbackendotp;
                                Toast.makeText(Verifyotpscreentwo.this, "OTP Sent again", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .build());
            }
        });
    }


    private void initiateotp() {

        //New function
        PhoneAuthProvider.verifyPhoneNumber(PhoneAuthOptions.newBuilder(auth).setPhoneNumber(phone)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(this)
                .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                        otp.getEditText().setText(phoneAuthCredential.getSmsCode());
                        signInWithPhoneAuthCredential(phoneAuthCredential);
                        progressBar.setVisibility(View.GONE);
                        verifyotp.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {
                        Toast.makeText(Verifyotpscreentwo.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCodeSent(@NonNull String backendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                        getotpbackend = backendotp;
                    }
                })
                .build());


//        Deprecated version
//        PhoneAuthProvider.getInstance().verifyPhoneNumber(phone, 60, TimeUnit.SECONDS, Verifyotpscreen.this,
//                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
//
//
//                    @Override
//                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
//
//
//                        otp.getEditText().setText(phoneAuthCredential.getSmsCode());
//                        signInWithPhoneAuthCredential(phoneAuthCredential);
//                        progressBar.setVisibility(View.GONE);
//                        verifyotp.setVisibility(View.VISIBLE);
//
//
//                    }
//
//                    @Override
//                    public void onVerificationFailed(@NonNull FirebaseException e) {
//
//
//                        Toast.makeText(Verifyotpscreen.this, e.getMessage(), Toast.LENGTH_SHORT).show();
//
//
//                    }
//
//                    @Override
//                    public void onCodeSent(@NonNull String backendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
//
//
//                        getotpbackend = backendotp;
//
//
//                    }
//                });

    }

    //Sign in using phone authentication credentials
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        progressBar.setVisibility(View.GONE);
                        verifyotp.setVisibility(View.VISIBLE);
                        Log.i("OTP ---->", getotpbackend);


                        if (task.isSuccessful()) {

                            String id = task.getResult().getUser().getUid();
                            Userdetailsmodel userdetailsmodel = new Userdetailsmodel(id, name, password, phone);
//                          store data in firebase
//                            database.getReference().child("Users").child(phone).
//                                    child("Userdetails").setValue(userdetailsmodel);
                            startActivity(new Intent(Verifyotpscreentwo.this, MainActivity.class));
                            finish();


                        } else {

                            Toast.makeText(Verifyotpscreentwo.this, "Enter the correct otp", Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }


    private void timerfunction() {
        timerview.setVisibility(View.VISIBLE);
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                timerview.setText(sDuration);
            }

            @Override
            public void onFinish() {

                resendotptext.setVisibility(View.GONE);
                resendotp.setVisibility(View.VISIBLE);
                timerview.setVisibility(View.GONE);

            }
        }.start();


    }
}