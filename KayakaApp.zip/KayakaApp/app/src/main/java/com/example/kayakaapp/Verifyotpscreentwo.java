package com.example.kayakaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;

public class Verifyotpscreentwo extends AppCompatActivity {

    MaterialButton verifyotp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifyotpscreentwo);

        verifyotp = findViewById(R.id.verify_otp);

        verifyotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Verifyotpscreentwo.this, Setpassword.class));
            }
        });
    }
}