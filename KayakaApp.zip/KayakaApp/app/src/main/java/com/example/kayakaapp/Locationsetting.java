package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Locationsetting extends AppCompatActivity {

    TextInputLayout fulladdress, pincode;
    MaterialButton update;

    FirebaseDatabase database;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locationsetting);

        fulladdress = findViewById(R.id.address);
        pincode = findViewById(R.id.pincode);
        update = findViewById(R.id.update);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        loadlocation();

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ( !validate_text(fulladdress) | !validate_text(pincode) ) {
                    return;
                }

                database.getReference()
                        .child("Users/"+auth.getCurrentUser().getPhoneNumber()+"/address/fulladdress")
                        .setValue(fulladdress.getEditText().getText().toString());
                database.getReference()
                        .child("Users/"+auth.getCurrentUser().getPhoneNumber()+"/address/pincode")
                        .setValue(pincode.getEditText().getText().toString());
                onBackPressed();
            }
        });
    }

    private void loadlocation() {

        database.getReference().child("Users").child(auth.getCurrentUser().getPhoneNumber())
                .child("address").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            if (dataSnapshot.getKey().equals("fulladdress")) {
                                fulladdress.getEditText().setText(dataSnapshot.getValue(String.class));
                            } else {
                                pincode.getEditText().setText(dataSnapshot.getValue(String.class));
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}