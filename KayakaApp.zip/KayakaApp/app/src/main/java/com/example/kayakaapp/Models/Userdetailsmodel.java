package com.example.kayakaapp.Models;

public class Userdetailsmodel {

    String name, phonenumber, password , profilepic, id, dob, gender, rating;

    public Userdetailsmodel() {
    }

    public Userdetailsmodel(String name, String phonenumber,
                            String password, String profilepic,
                            String id, String dob, String gender,
                            String rating) {
        this.name = name;
        this.phonenumber = phonenumber;
        this.password = password;
        this.profilepic = profilepic;
        this.id = id;
        this.dob = dob;
        this.gender = gender;
        this.rating = rating;
    }

    public Userdetailsmodel(String name, String phonenumber, String password, String profilepic, String id) {
        this.name = name;
        this.phonenumber = phonenumber;
        this.password = password;
        this.profilepic = profilepic;
        this.id = id;
    }

    public Userdetailsmodel(String id, String name, String password, String phonenumber) {
        this.name = name;
        this.phonenumber = phonenumber;
        this.password = password;
        this.id = id;
    }

    public Userdetailsmodel(String name, String dob, String gender) {
        this.name = name;
        this.dob = dob;
        this.gender = gender;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getProfilepic() {
        return profilepic;
    }

    public void setProfilepic(String profilepic) {
        this.profilepic = profilepic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
