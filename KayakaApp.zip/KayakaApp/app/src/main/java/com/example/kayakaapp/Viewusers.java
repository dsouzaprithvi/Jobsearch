package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kayakaapp.Adapters.Usersadapter;
import com.example.kayakaapp.Adapters.Viewuseradapter;
import com.example.kayakaapp.Models.Applymodel;
import com.example.kayakaapp.Models.Userdetailsmodel;
import com.example.kayakaapp.Models.Viewuser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Viewusers extends AppCompatActivity {

    FirebaseAuth auth;
    FirebaseDatabase database;

    ArrayList<Applymodel> usersholder;
    Viewuseradapter  adapter;
    RecyclerView recyclerView;

    Userdetailsmodel userinfo;

    String time, pincode;
    Float rating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewusers);

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(Viewusers.this));

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();



        usersholder = new ArrayList<>();
        adapter = new Viewuseradapter(Viewusers.this, usersholder);
        adapter.setOnItemClickListener(new Viewuseradapter.OnItemClickListener() {
            @Override
            public void onCardviewclick(int position) {
                String phone = usersholder.get(position).getUsernumber();
                database.getReference().child("Users").child(phone).child("Userdetails")
                        .addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                userinfo = snapshot.getValue(Userdetailsmodel.class);
                                onButtonShowPopupWindowClick();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
            }
        });
        recyclerView.setAdapter(adapter);


//        Log.i("Pincode----ds//",pincode);

        loaddata();

    }

    private void loaddata () {

        pincode = getIntent().getStringExtra("Pincode");
        time = getIntent().getStringExtra("Time");

        String id = auth.getCurrentUser().getPhoneNumber();

        database.getReference().child("Posts").child(pincode).child(id)
                .child(time).child("ApplyRequest").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        usersholder.clear();
                        for ( DataSnapshot dataSnapshot : snapshot.getChildren() ) {
                            Applymodel users = dataSnapshot.getValue(Applymodel.class);
                            usersholder.add(users);
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }

    public void onButtonShowPopupWindowClick (){

        // inflate the layout of the popup window

//        LayoutInflater inflater = (LayoutInflater)
//                getActivity().getSystemService(LAYOUT_INFLATER_SERVICE);
//        View popupView = inflater.inflate(R.layout.layout_bottom_sheet_password, null);
////        Drawable background = ContextCompat.getDrawable(Settings.this, R.drawable.res_black_menuroundfilled_corner);
//        popupView.setBackground(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//
//        // create the popup window
//        int width = LinearLayout.LayoutParams.MATCH_PARENT;
//        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
//        boolean focusable = true; // lets taps outside the popup also dismiss it
//        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
//
//        // show the popup window
//        // which view you pass in doesn't matter, it is only used for the window tolken
//        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
//
//        // dismiss the popup window when touched
//        popupView.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                popupWindow.dismiss();
//                return true;
//            }
//        });

        Dialog builder = new Dialog(Viewusers.this);
        builder.requestWindowFeature(Window.FEATURE_NO_TITLE);
        builder.setCancelable(true);
        builder.setContentView(R.layout.rate_user);
        ImageView profile = builder.findViewById(R.id.profile_pic);
        TextView username = builder.findViewById(R.id.user_name);
        RatingBar ratingBar = builder.findViewById(R.id.rating);
        Button update = builder.findViewById(R.id.update);
        Picasso.get().load(userinfo.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profile);
        username.setText(userinfo.getName());
        rating = Float.parseFloat(userinfo.getRating());

        builder.getWindow().setBackgroundDrawable(
                new ColorDrawable(android.graphics.Color.TRANSPARENT));
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
            }
        });
        builder.show();

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String rate = String.valueOf(ratingBar.getRating());
                DecimalFormat df = new DecimalFormat("#.##");
                rating = (rating+ratingBar.getRating())/2;
                database.getReference().child("Users").child(userinfo.getPhonenumber())
                        .child("Userdetails").child("rating").setValue(String.valueOf(df.format(rating)));
                builder.dismiss();
                Toast.makeText(Viewusers.this, "Rated successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Viewusers.this, MainActivity.class));
                finish();
            }
        });

    }
}