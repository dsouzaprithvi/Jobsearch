package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.kayakaapp.Models.Postsmodel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Editpost extends AppCompatActivity {

    AutoCompleteTextView jobcategory;
    ArrayAdapter<String> adapterjobcategory;
    String[] jobcategories;

    MaterialButton save, post;
    TextInputLayout jobtitle, jobdescription, joblocation, pincode, startpay, endpay;

    RadioButton radioButton, createjob, needjob, fixed, range, perhour, perday, lumpsum,
            yes, no;
    RadioGroup jobtype, paymentype, payas, paymentmethod;

    FirebaseAuth auth;
    FirebaseDatabase database;

    String phone, currentdatetime, Pincode, Jobcategory, posttype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editpost);

        createjob = findViewById(R.id.create_job);
        needjob = findViewById(R.id.need_job);
        fixed = findViewById(R.id.fixed);
        range = findViewById(R.id.range);
        perhour = findViewById(R.id.perhour);
        perday = findViewById(R.id.perday);
        lumpsum = findViewById(R.id.lumpsum);
        yes = findViewById(R.id.yes);
        no = findViewById(R.id.no);
        save = findViewById(R.id.save);
        post = findViewById(R.id.post);
        jobtitle = findViewById(R.id.job_title);
        jobdescription = findViewById(R.id.job_description);
        joblocation = findViewById(R.id.job_location);
        pincode = findViewById(R.id.pincode);
        startpay = findViewById(R.id.start_pay);
        endpay = findViewById(R.id.end_pay);
        jobtype = findViewById(R.id.job_type);
        paymentype = findViewById(R.id.payment_type);
        payas = findViewById(R.id.pay_as);
        paymentmethod = findViewById(R.id.payment_method);


        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        phone =  auth.getCurrentUser().getPhoneNumber();


        jobcategories = new String[]{"Housekeeping" , "Grocery Shopping", "Elderly care",
                "Electrician", "Driver", "Computer and TV repair", "AC Mechanic", "Others"};
        jobcategory = (AutoCompleteTextView) findViewById(R.id.job_category);
        adapterjobcategory = new ArrayAdapter<String>(Editpost.this, R.layout.list_item,jobcategories);
        jobcategory.setAdapter(adapterjobcategory);

        jobcategory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Jobcategory = adapterView.getItemAtPosition(i).toString();
            }
        });

        database.getReference().child("Users/"+phone+"/address/pincode")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Pincode = snapshot.getValue(String.class);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


//        jobtitle.getEditText().setText(getIntent().getStringExtra("Time"));

        posttype = getIntent().getStringExtra("Posts");
        currentdatetime = getIntent().getStringExtra("Time");
        String pin = getIntent().getStringExtra("Pincode");
        Log.i("Posttype---->>>>", posttype);
        Log.i("date---->>>>", currentdatetime);
        Log.i("pin---->>>>", pin);

        if (posttype.equals("yes")) {
            database.getReference().child("Posts").child(pin).child(phone).child(currentdatetime)
                    .child("Postdetails")
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            try {
                                Postsmodel postsmodel = snapshot.getValue(Postsmodel.class);
                                jobtitle.getEditText().setText(postsmodel.getTitle());
                                jobdescription.getEditText().setText(postsmodel.getDescription());
                                joblocation.getEditText().setText(postsmodel.getLocation());
                                pincode.getEditText().setText(postsmodel.getPincode());
                                startpay.getEditText().setText(postsmodel.getStartpay());
                                endpay.getEditText().setText(postsmodel.getEndpay());
                            } catch (NullPointerException e) {
                                Toast.makeText(Editpost.this, "No posts Present", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

        } else {
            database.getReference().child("Users").child(phone).child("Savedposts").child(currentdatetime)
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            try {
                                Postsmodel postsmodel = snapshot.getValue(Postsmodel.class);
                                jobtitle.getEditText().setText(postsmodel.getTitle());
                                jobdescription.getEditText().setText(postsmodel.getDescription());
                                joblocation.getEditText().setText(postsmodel.getLocation());
                                pincode.getEditText().setText(postsmodel.getPincode());
                                startpay.getEditText().setText(postsmodel.getStartpay());
                                endpay.getEditText().setText(postsmodel.getEndpay());
                            } catch (NullPointerException e) {
                                Toast.makeText(Editpost.this, "No posts Present", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

        }


        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!(createjob.isChecked() || needjob.isChecked()) |
                        !(fixed.isChecked() || range.isChecked()) |
                        !(perday.isChecked() || perhour.isChecked() || lumpsum.isChecked()) |
                        !(yes.isChecked() || no.isChecked())) {
                    Toast.makeText(Editpost.this, "Field not selected", Toast.LENGTH_SHORT).show();
                    return;
                }

                if ( !validate(jobtitle) | !validate(jobdescription) | !validate(joblocation) |
                        !validate(pincode) | !validate(startpay) | !validate(endpay) ) {
                    return;
                }



//                currentdatetime = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss", Locale.getDefault()).format(new Date());
                String job_type, payment_type, pay_as, pay_by_cash;
                job_type = radiobuttonlistener(jobtype);
                payment_type = radiobuttonlistener(paymentype);
                pay_as = radiobuttonlistener(payas);
                pay_by_cash = radiobuttonlistener(paymentmethod);
                Postsmodel postsmodel = new Postsmodel(job_type, jobtitle.getEditText().getText().toString(),
                        jobdescription.getEditText().getText().toString(), Jobcategory, joblocation.getEditText().getText().toString(),
                        pincode.getEditText().getText().toString(),
                        payment_type, startpay.getEditText().getText().toString(), endpay.getEditText().getText().toString(),
                        pay_as, pay_by_cash, "Activepost", currentdatetime, phone);
                database.getReference().child("Posts").child(pincode.getEditText().getText().toString()).child(auth.getCurrentUser().getPhoneNumber())
                        .child(currentdatetime).child("Postdetails").setValue(postsmodel);
                Toast.makeText(Editpost.this, "Posted Successfully", Toast.LENGTH_SHORT).show();
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!(createjob.isChecked() || needjob.isChecked()) |
                        !(fixed.isChecked() || range.isChecked()) |
                        !(perday.isChecked() || perhour.isChecked() || lumpsum.isChecked()) |
                        !(yes.isChecked() || no.isChecked())) {
                    Toast.makeText(Editpost.this, "Field not selected", Toast.LENGTH_SHORT).show();
                    return;
                }

                if ( !validate(jobtitle) | !validate(jobdescription) | !validate(joblocation) |
                        !validate(pincode) | !validate(startpay) | !validate(endpay) ) {
                    return;
                }



//                currentdatetime = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss", Locale.getDefault()).format(new Date());
                String job_type, payment_type, pay_as, pay_by_cash;
                job_type = radiobuttonlistener(jobtype);
                payment_type = radiobuttonlistener(paymentype);
                pay_as = radiobuttonlistener(payas);
                pay_by_cash = radiobuttonlistener(paymentmethod);
                Postsmodel postsmodel = new Postsmodel(job_type, jobtitle.getEditText().getText().toString(),
                        jobdescription.getEditText().getText().toString(), Jobcategory, joblocation.getEditText().getText().toString(),
                        pincode.getEditText().getText().toString(),
                        payment_type, startpay.getEditText().getText().toString(), endpay.getEditText().getText().toString(),
                        pay_as, pay_by_cash, "Saved", currentdatetime, phone);
                database.getReference().child("Users").child(phone).child("Savedposts").child(currentdatetime)
                        .setValue(postsmodel);
                Toast.makeText(Editpost.this, "Post Saved", Toast.LENGTH_SHORT).show();
            }
        });



    }

    private String radiobuttonlistener(RadioGroup radioGroup) {
        int selectID = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(selectID);
        return radioButton.getText().toString();
    }



    private boolean validate(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }
}