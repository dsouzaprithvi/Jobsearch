package com.example.kayakaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.kayakaapp.Models.Userdetailsmodel;
import com.example.kayakaapp.databinding.ActivityViewpostandapplyBinding;
import com.example.kayakaapp.databinding.ActivityViewprofileBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Viewprofile extends AppCompatActivity {

    private ActivityViewprofileBinding binding;

    FirebaseAuth auth;
    FirebaseDatabase database;

    String username, userid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewprofileBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);


        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        String phone = getIntent().getStringExtra("Phonenumber");
        database.getReference().child("Users").child(phone)
                .child("Userdetails")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Userdetailsmodel user = snapshot.getValue(Userdetailsmodel.class);
                username = user.getName();
                userid = user.getId();
                Picasso.get().load(user.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(binding.profilePic);
                binding.userName.setText(username);
                binding.phoneNumber.setText(user.getPhonenumber());
                try {
                    binding.rating.setRating(Float.parseFloat(user.getRating()));
                } catch (NullPointerException e) {

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        binding.chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Viewprofile.this, Chatscreen.class);
                intent.putExtra("Username", username);
                intent.putExtra("Userid", userid);
                startActivity(intent);

            }
        });

    }

    private void loaduserdata() {
        database.getReference().child("Users/"+auth.getCurrentUser().getPhoneNumber()+"/Userdetails").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Userdetailsmodel user = snapshot.getValue(Userdetailsmodel.class);
                username = user.getName();
                userid = user.getId();
                Intent intent = new Intent(Viewprofile.this, Chatscreen.class);
                intent.putExtra("Username", username);
                intent.putExtra("Userid", userid);
                startActivity(intent);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}