package com.example.kayakaapp.Spinnerfragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.kayakaapp.Adapters.Postviewadapter;
import com.example.kayakaapp.Models.Applymodel;
import com.example.kayakaapp.Models.Postsmodel;
import com.example.kayakaapp.R;
import com.example.kayakaapp.Viewpostandapply;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;

import java.util.ArrayList;


public class Requestpendingfragment extends Fragment {

    ArrayList<Postsmodel> postholder;
    Postviewadapter adapter;
    RecyclerView recyclerView;


    FirebaseAuth auth;
    FirebaseDatabase database;

    String pincode;
    int urpin;

    public Requestpendingfragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_requestpendingfragment, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        postholder = new ArrayList<>();
        adapter = new Postviewadapter(getContext(), postholder);
        recyclerView.setAdapter(adapter);

        loaddata();

        return view;
    }

    private void loaddata() {

        String phone = auth.getCurrentUser().getPhoneNumber();

        database.getReference().child("Posts")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        postholder.clear();
                        for (DataSnapshot pincode : snapshot.getChildren()) {
                            String pin = pincode.getKey();
                            for (DataSnapshot postid : pincode.getChildren()) {
                                String mob = postid.getKey();
                                for (DataSnapshot date : postid.getChildren()) {
                                    String day = date.getKey();
                                    for (DataSnapshot getrequest : date.getChildren()) {
                                        if (getrequest.getKey().equals("ApplyRequest")) {
                                            for (DataSnapshot getuser : getrequest.getChildren()) {
                                                if (getuser.getKey().equals(phone)) {
                                                    getpost(pin, mob, day);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
//                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void getpost(String pin, String mob, String day) {
        database.getReference().child("Posts")
                .child(pin)
                .child(mob)
                .child(day)
                .child("Postdetails")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Postsmodel posts = snapshot.getValue(Postsmodel.class);
                        if ( posts.getStatus().equals("Activepost") ) {
                            postholder.add(posts);
                        }
                        adapter.notifyDataSetChanged();
                        adapter.setOnLongClickListener(new Postviewadapter.OnItemLongClickListener() {
                            @Override
                            public void onLongClick(int position) {
                                removeItem(position);
                            }
                        });
                        adapter.setOnItemClickListener(new Postviewadapter.OnItemClickListener() {
                            @Override
                            public void onCardviewclick(int position) {
                                Intent intent = new Intent(getContext(), Viewpostandapply.class);
                                Gson gson = new Gson();
                                String myJson = gson.toJson(postholder.get(position));
                                intent.putExtra("Postdata", myJson);
                                intent.putExtra("Appliedfragment", "yes");
                                startActivity(intent);
                            }
                        });
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    public void removeItem(int position) {
        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setIcon(R.drawable.ic_baseline_warning_24)
                .setTitle("Delete")
                .setMessage("Are you sure to delete the applied post")
                .setPositiveButton("OK", null)
                .setNegativeButton("Cancel", null)
                .show();

        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        positiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pin = postholder.get(position).getPincode();
                String mobnumber = postholder.get(position).getPhonenumber();
                String date = postholder.get(position).getDatetime();
                postholder.remove(position);
                adapter.notifyItemRemoved(position);
                database.getReference().child("Posts")
                        .child(pin)
                        .child(mobnumber)
                        .child(date)
                        .child("ApplyRequest")
                        .child(auth.getCurrentUser().getPhoneNumber())
                        .removeValue();
                dialog.dismiss();
            }
        });
    }
}